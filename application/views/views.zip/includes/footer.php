
	<!-- Placed at the end of the document so the pages load faster ============================================= -->
    <script src="<?= base_url('assets/themes/js/jquery.js'); ?>" type="text/javascript"></script>
    <script src="<?= base_url('assets/themes/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
    <script src="<?= base_url('assets/themes/js/google-code-prettify/prettify.js'); ?>"></script>
    
    <script src="<?= base_url('assets/themes/js/bootshop.js'); ?>"></script>
    <script src="<?= base_url('assets/themes/js/jquery.lightbox-0.5.js'); ?>"></script>
    
	<!-- Footer ================================================================== -->
	<div  id="footerSection">
	<div class="container" style="margin-bottom: -2%;">
		<p class="pull-right" style="color: white;">&copy; ABCMovies</p>
	</div><!-- Container End -->
	</div>

</body>
</html>